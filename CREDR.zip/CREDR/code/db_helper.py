# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 08:49:28 2020

@author: vishal
"""

import psycopg2
from psycopg2.pool import SimpleConnectionPool
from contextlib import contextmanager

try:
    DB_STR = "dbname= 'postgres' user = 'postgres' host = 'localhost' password = 'root' port = '5432' "
    CON_POOL = SimpleConnectionPool(1,10,dsn=DB_STR)
except psycopg2.Databaseerror as error:
    print(error)
    
@contextmanager    
def getcorsur():
    con = CON_POOL.getconn()
    try:
        yield con.cursor()
        con.commit()
    finally:
        CON_POOL.putconn(con)
        
def get_vehicle_details(vehicle_name):
    try:
        query = "select price from  vehicle.vehicle_details where vehicle_name = '"+vehicle_name+"' and years = '2005'"
        with getcorsur() as cur:
            cur.execute(query)
            res = cur.fetchall()
            return res
    except psycopg2.Databaseerror as error:
        print(error)
            
        
        
def get_velicle_colour_baseprice(vehicle_name,colour):
    try:
        query = "select price from  vehicle.vehicle_details where vehicle_name = '"+vehicle_name+"' and colour = '"+colour+"'"
        with getcorsur() as cur:
            cur.execute(query)
            res = cur.fetchall()
            return res
    except psycopg2.Databaseerror as error:
        print(error)


def get_vehicle_model(vehicle_name):
    try:
        query = "select vehicle_model from  vehicle.vehicle_details where vehicle_name = '"+vehicle_name+"'"
        with getcorsur() as cur:
            cur.execute(query)
            res = cur.fetchall()
            return res
    except psycopg2.Databaseerror as error:
        print(error)
    
    