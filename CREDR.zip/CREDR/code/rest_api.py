# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 21:22:24 2020
@author: vishal
"""
from flask import Flask, jsonify, request
import db_helper 
app = Flask(__name__) 

@app.route('/vehicle_price', methods = ['GET']) 
def vehicle_price():
    if(request.method == 'GET'):
        vehicle_name = request.args['vehicle'].lower()
        damage = request.args['damage']
        damage1 = request.args['damage1']
        year = request.args['year']
        old_price = db_helper.get_vehicle_details(vehicle_name)
        if len(old_price) !=0:
            old_price = old_price[0][0]
            deduction = int(year) - 2005
            ded_percent = deduction * 5
            if (damage is None or damage == '') and (damage1 is None or damage1 == ''):
                pass
            elif (damage is None or damage == '') or (damage1 is None or damage1 == ''):
                ded_percent = ded_percent + 2
            else:
                ded_percent = ded_percent + 4
            print(ded_percent)
            price = int(old_price) - int(old_price)*ded_percent/100
            return jsonify({"price":str(price)}),200
        return "Vehicle is not available now",200
    else:
        return jsonify("Its Get Method"),400


@app.route('/price_base_on_colour',methods = ['GET'])
def price_base_on_colour():
    if(request.method == 'GET'):
        vehicle_name = request.args['vehicle'].lower()
        vehicle_colour = request.args['colour'].lower()
        price = db_helper.get_velicle_colour_baseprice(vehicle_name,vehicle_colour)
        if len(price) !=0:
            return jsonify({"Vehicle Name":vehicle_name,"Vehicle colour":vehicle_colour,"Vehicle price":price[0][0]}),200
        else:
            return jsonify("Vehicle not found now,please try after some time"),200
    return jsonify("Its Get Method"),400


@app.route('/all_model',methods = ['GET'])
def vehicle_model():
    if(request.method == 'GET'):
        model_list = []
        vehicle_name = request.args['vehicle'].lower()
        vehicle_model = db_helper.get_vehicle_model(vehicle_name)
        if len(vehicle_model) != 0:
            for i in vehicle_model:
                model_list.append(i[0])
            lists = " , ".join(model_list)
            return jsonify({"Vehicle model":lists}),200
        return jsonify("Vehicle Not Found"),200
    return jsonify("Its Get Method"),400
            
        


if __name__ == '__main__': 

	app.run(debug = False) 
